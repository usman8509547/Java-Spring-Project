package com.embarkmobile.androidexample;

/**
 *
 */
public class Counter {
    private int value;

    public int increment() {
        return ++value;
    }

    public int getValue() {
        return value;
    }
}
